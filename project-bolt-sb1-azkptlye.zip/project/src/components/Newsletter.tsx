import React from 'react';

export default function Newsletter() {
  return (
    <section className="py-16 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold mb-4">Rejoignez Notre Communauté</h2>
        <p className="mb-8 text-gray-300 max-w-2xl mx-auto">
          Inscrivez-vous pour recevoir en avant-première nos nouveautés, nos offres exclusives et nos conseils mode.
        </p>
        <div className="flex max-w-md mx-auto">
          <input
            type="email"
            placeholder="Votre email"
            className="flex-1 px-4 py-2 text-black"
          />
          <button className="bg-white text-black px-6 py-2 ml-2 hover:bg-gray-100 transition-colors">
            S'inscrire
          </button>
        </div>
      </div>
    </section>
  );
}