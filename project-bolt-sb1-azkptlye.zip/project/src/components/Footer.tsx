import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-black text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">À Propos</h3>
            <ul className="space-y-2">
              <li className="hover:text-gray-300 cursor-pointer">Notre Histoire</li>
              <li className="hover:text-gray-300 cursor-pointer">Développement Durable</li>
              <li className="hover:text-gray-300 cursor-pointer">Carrières</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Service Client</h3>
            <ul className="space-y-2">
              <li className="hover:text-gray-300 cursor-pointer">Contact</li>
              <li className="hover:text-gray-300 cursor-pointer">Livraison</li>
              <li className="hover:text-gray-300 cursor-pointer">Retours</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Légal</h3>
            <ul className="space-y-2">
              <li className="hover:text-gray-300 cursor-pointer">Mentions Légales</li>
              <li className="hover:text-gray-300 cursor-pointer">Confidentialité</li>
              <li className="hover:text-gray-300 cursor-pointer">CGV</li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold mb-4">Suivez-nous</h3>
            <p className="text-gray-300 mb-4">
              Retrouvez-nous sur les réseaux sociaux pour plus d'inspiration mode.
            </p>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>© 2024 LOKMANE. Tous droits réservés.</p>
        </div>
      </div>
    </footer>
  );
}