import React from 'react';

const categories = [
  {
    id: 1,
    name: 'Collection Homme',
    image: 'https://images.unsplash.com/photo-1516826957135-700dedea698c?auto=format&fit=crop&q=80',
    link: '#'
  }
];

export default function Categories() {
  return (
    <section className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8">
          {categories.map((category) => (
            <div key={category.id} className="relative h-[600px] group overflow-hidden">
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black/20" />
              <div className="absolute inset-0 flex items-center justify-center">
                <a
                  href={category.link}
                  className="bg-white px-8 py-3 text-lg font-medium hover:bg-gray-100 transition-colors"
                >
                  {category.name}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}