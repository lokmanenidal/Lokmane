import React from 'react';
import { Leaf, Recycle, Heart } from 'lucide-react';

const initiatives = [
  {
    icon: <Leaf className="h-8 w-8" />,
    title: 'Matériaux Durables',
    description: 'Nous utilisons des matériaux biologiques et recyclés pour minimiser notre impact environnemental.'
  },
  {
    icon: <Recycle className="h-8 w-8" />,
    title: 'Production Éthique',
    description: 'Nos vêtements sont fabriqués dans des conditions équitables et respectueuses de l\'environnement.'
  },
  {
    icon: <Heart className="h-8 w-8" />,
    title: 'Mode Responsable',
    description: 'Nous créons des pièces intemporelles qui durent plus longtemps et réduisent le gaspillage.'
  }
];

export default function Sustainability() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">Notre Engagement Durable</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {initiatives.map((item, index) => (
            <div key={index} className="text-center">
              <div className="flex justify-center mb-4">{item.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}