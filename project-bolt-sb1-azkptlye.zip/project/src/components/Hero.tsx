import React from 'react';

export default function Hero() {
  return (
    <div className="relative h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80"
          alt="Fashion hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/30" />
      </div>
      
      <div className="relative h-full flex items-center justify-center text-center">
        <div className="max-w-3xl px-4">
          <h1 className="text-6xl md:text-8xl font-bold text-white mb-6 brand-name">
            LOKMANE
          </h1>
          <p className="text-xl md:text-2xl text-white mb-8">
            La mode intemporelle pour l'homme moderne
          </p>
          <button className="bg-white text-black px-8 py-3 text-lg font-medium hover:bg-gray-100 transition-colors">
            Découvrir la Collection
          </button>
        </div>
      </div>
    </div>
  );
}